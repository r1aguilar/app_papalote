//
//  selectorFotos.swift
//  proyectoReto
//
//  Created by Pedr1p on 04/11/24.
//

import SwiftUI

struct selectorFotos: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    selectorFotos()
}
