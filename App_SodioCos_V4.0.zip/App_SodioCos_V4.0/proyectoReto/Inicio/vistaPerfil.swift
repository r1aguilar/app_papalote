//
//  vistaPerfil.swift
//  proyectoReto
//
//  Created by Pedr1p on 04/11/24.
//

import SwiftUI

struct vistaPerfil: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        ZStack {
            NavigationStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss() // Cierra la vista actual
                }) {
                    Image(systemName: "arrow.left")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .font(.system(size: 20))
                        .frame(width: 25)
                        .foregroundColor(.black)
                        .padding(10)
                        .background(Color(white: 1))
                        .clipShape(Circle())
                }
                .offset(x: -UIScreen.screenWidth / 2 + 35, y: -370)
            }
            VStack {
                Text("Perfil")
                    .font(.title)
                    .bold()
            }
            .offset(y: -370)
            VStack {
                
            }
        }
    }
}

#Preview {
    vistaPerfil()
}
