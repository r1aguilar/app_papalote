//
//  ContentView.swift
//  ViewActividadPapalote
//
//  Created by Alumno on 14/10/24.
//

import SwiftUI

struct ContentViewActividades: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    ContentViewActividades()
}
