//
//  appState.swift
//  proyectoReto
//
//  Created by Pedr1p on 13/10/24.
//

import Foundation

struct AppState: Codable {
    var pertenezcoCompletado: Bool
}

